INSERT INTO review VALUES ('0000000000000000000001', '2012-05-01', 'textBox',  5 , '---1lKK3aKOuomHnwAkAow ', 'Xspg78dOvuedvuPEUwZBjw')



select * 
from review
where userid ='---1lKK3aKOuomHnwAkAow'

select *
from business
where businessid='Xspg78dOvuedvuPEUwZBjw'

insert into review
values ('0000000000000000000000', '2012-05-01', 'Test bruh', 5, 'ubhWEcKfcBm5lJMNgxwu-Q', 'Xspg78dOvuedvuPEUwZBjw')

select friendid
from friends
where userid='---1lKK3aKOuomHnwAkAow'

select *
from review 
where reviewid='0000000000000000000000'

select firstname 
from users, friends as f2
where f2.friendid=users.userid and f2.userid='---1lKK3aKOuomHnwAkAow'
order by firstname

insert into users(firstname, lastname)
Values ('Test','Test')

select * from users where firstname='Test'








--1 userid search
"select userid from users where firstname like '" + textbox.text() + "'% order by userid;"

--2 user info
select firstname, avgstars, joindate, lat, long from users where userid= 'selected'

--3 fans
select count(*) from friends where friendid='selected'

--4 update long, lat
update users set lat = 'latbox', long= 'longbox ' where userid='selected'

--5 friends 
select firstname, avgstars, joindate from friends where userid='selected'

--6 favorite Businesses
select name, avgrating, city, zipcode, address from favorite natural join business where userid='selected'

--7 friends reviews
select firstname, name, city, reviewtext from 

select * from friends natural join review where 

select * from users where joindate = (select max(joindate) from users)

select max(joindate) from users

select * from users where joindate = (select max(joindate) from users where userid='---1lKK3aKOuomHnwAkAow') and userid ='---1lKK3aKOuomHnwAkAow'
---1lKK3aKOuomHnwAkAow
selectedFriends

select *
from (select firstname, name, reviewdate, reviewtext from review as r, users as u, business as b where u.userid=r.userid and b.businessid=r.businessid and r.userid = '---1lKK3aKOuomHnwAkAow'
) as q where revew

--final version of 7
select  firstname, name, reviewdate, reviewtext  from (review natural join users) as r, business as b where b.businessid=r.businessid and userid = 'selected friend'
and reviewdate>=(select max(reviewdate) from review where userid='selected friend')
